(function () {
  'use strict';
  var C = window.CONFIG, N = window.NPCrypto;

  var T = {
    required: 'ટેનામેન્ટ નંબર અને મોબાઇલ નંબર (10 અંક) બંને ફરજિયાત છે.',
    mismatch: 'વિગતો મેળ ખાતી નથી અથવા બિલ ઉપલબ્ધ નથી. ટેનામેન્ટ નંબર અને બિલમાં નોંધાયેલ મોબાઇલ નંબર ફરી તપાસો.',
    locked: 'ઘણા ખોટા પ્રયત્નો થયા. {m} મિનિટ પછી ફરી પ્રયત્ન કરો.',
    network: 'ઇન્ટરનેટની સમસ્યા આવી. થોડી વાર પછી ફરી પ્રયત્ન કરો.',
    busy: 'ચકાસણી ચાલુ છે… થોડી રાહ જુઓ.'
  };

  function $(id) { return document.getElementById(id); }
  var form = $('f'), msg = $('msg'), go = $('go'), done = $('done'), again = $('again');
  var currentUrl = null, urlTimer = null;

  if (C.EXTRA_ENABLED) {
    $('extraWrap').hidden = false;
    $('extraLabel').textContent = C.EXTRA_LABEL + ' *';
  }

  function show(text, kind) {
    msg.textContent = text || '';
    msg.className = 'msg ' + (kind || 'err');
    msg.hidden = !text;
  }

  // ---- Halki rok (sirf us browser me; asli suraksha encryption se hai) ----
  var KEY = 'np_fail';
  function readState() {
    try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; }
  }
  function writeState(s) {
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* private window */ }
  }
  var memState = null; // localStorage na chale to memory me
  function state() { return memState || readState(); }
  function save(s) { memState = s; writeState(s); }
  function lockedMinutes() {
    var s = state();
    return s.until && s.until > Date.now() ? Math.ceil((s.until - Date.now()) / 60000) : 0;
  }
  function recordFail() {
    var s = state();
    s.n = (s.n || 0) + 1;
    if (s.n >= C.MAX_FAILS) { s.until = Date.now() + C.LOCK_MINUTES * 60000; s.n = 0; }
    save(s);
  }

  function clearUrl() {
    if (urlTimer) { clearTimeout(urlTimer); urlTimer = null; }
    if (currentUrl) { URL.revokeObjectURL(currentUrl); currentUrl = null; }
    again.removeAttribute('href');
  }

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    done.hidden = true;
    clearUrl();

    var t = N.normTenement($('tenement').value);
    var m = N.normMobile($('mobile').value);
    var x = C.EXTRA_ENABLED ? N.normExtra($('extra').value) : null;
    if (!t || !m || (C.EXTRA_ENABLED && !x)) { show(T.required); return; }

    var lock = lockedMinutes();
    if (lock) { show(T.locked.replace('{m}', lock)); return; }

    go.disabled = true;
    show(T.busy, 'info');
    try {
      var id = await N.fileId(C.SITE_ID, t);
      var res = await fetch(C.BILL_DIR + '/' + id + '.bin', {
        cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer'
      });
      if (res.status === 404) { recordFail(); show(T.mismatch); return; }
      if (!res.ok) { show(T.network); return; }

      var data = new Uint8Array(await res.arrayBuffer());
      var pdf;
      try {
        pdf = await N.decryptBill(data, { tenement: t, mobile: m, extra: x });
      } catch (err) {
        recordFail(); show(T.mismatch); return;
      }

      show('');
      currentUrl = URL.createObjectURL(new Blob([pdf], { type: 'application/pdf' }));
      again.href = currentUrl;
      again.download = 'Bill-' + t + '.pdf';
      done.hidden = false;
      again.click();
      $('mobile').value = '';
      if ($('extra')) { $('extra').value = ''; }
      urlTimer = setTimeout(function () { clearUrl(); done.hidden = true; }, 10 * 60 * 1000);
    } catch (err) {
      show(T.network);
    } finally {
      go.disabled = false;
    }
  });
})();

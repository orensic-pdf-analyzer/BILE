(function () {
  'use strict';
  var C = window.CONFIG, N = window.NPCrypto, Z = window.NPZip;

  var M = {
    NOT_PDF: 'PDF નથી',
    BAD_TENEMENT: 'ટેનામેન્ટ નંબર ખોટો (ફક્ત A-Z, 0-9, - ચાલે)',
    BAD_MOBILE: 'મોબાઇલ નંબર ખોટો (10 અંક જોઈએ)',
    NO_MOBILE: 'મોબાઇલ નંબર નથી (નામમાં કે CSV માં જોઈએ)',
    NO_EXTRA: 'વધારાનો કોડ નથી',
    UNEXPECTED_EXTRA: 'નામમાં વધારાનો ભાગ છે',
    BAD_NAME: 'ફાઇલનું નામ ખોટું',
    NOT_PDF_CONTENT: 'ફાઇલ અંદરથી PDF નથી',
    BIG: 'ફાઇલ બહુ મોટી છે',
    DUP: 'આ ટેનામેન્ટ આ વખતે ફરીથી આવ્યો, પહેલી ફાઇલ રાખી',
    OTHER: 'સમસ્યા આવી'
  };
  var CONCURRENCY = 4, PART_SIZE = 500, MAX_ERRORS_SHOWN = 50;

  function $(id) { return document.getElementById(id); }
  var dirHandle = null;

  $('nameHint').textContent = C.EXTRA_ENABLED
    ? 'ફાઇલનું નામ: ટેનામેન્ટ_મોબાઇલ_કોડ.pdf (જેમ કે 12345_9876543210_AB12.pdf)'
    : 'ફાઇલનું નામ: ટેનામેન્ટ_મોબાઇલ.pdf (જેમ કે 12345_9876543210.pdf)';

  if (typeof window.showDirectoryPicker === 'function') {
    $('dirWrap').hidden = false;
    $('zipFallback').hidden = false;
  } else {
    $('zipNote').hidden = false;
  }

  $('pickDir').addEventListener('click', async function () {
    try {
      dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
    } catch (e) { return; } // રદ કર્યું
    $('dirName').textContent = dirHandle.name;
    $('dirWarn').hidden = dirHandle.name === C.BILL_DIR;
  });

  function setStatus(text, kind) {
    var el = $('status');
    el.textContent = text || '';
    el.className = 'msg ' + (kind || 'info');
    el.hidden = !text;
  }

  function addItem(listId, text) {
    var li = document.createElement('li');
    li.textContent = text;
    $(listId).appendChild(li);
    return li;
  }

  async function listExisting(dir) {
    var set = new Set();
    for await (var entry of dir.entries()) {
      var name = entry[0], h = entry[1];
      if (h.kind === 'file' && /^[0-9a-f]{32}\.bin$/.test(name)) { set.add(name.slice(0, -4)); }
    }
    return set;
  }

  function dirSink(dir) {
    return {
      write: async function (name, data) {
        var fh = await dir.getFileHandle(name, { create: true });
        var w = await fh.createWritable();
        await w.write(data);
        await w.close();
      },
      finish: async function () {}
    };
  }

  function zipSink(onPart) {
    var buf = [], n = 0;
    function flush() {
      if (!buf.length) { return; }
      n++;
      var blob = new Blob(Z.makeZip(buf), { type: 'application/zip' });
      buf = [];
      onPart(n, blob);
    }
    return {
      write: async function (name, data) { buf.push({ name: name, data: data }); if (buf.length >= PART_SIZE) { flush(); } },
      finish: async function () { flush(); }
    };
  }

  function addDownload(listId, label, blob, fileName) {
    var li = document.createElement('li');
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = fileName;
    a.textContent = label;
    li.appendChild(a);
    $(listId).appendChild(li);
  }

  function csvCell(v) { return '"' + String(v).replace(/"/g, '""') + '"'; }

  async function run() {
    var startBtn = $('start');
    startBtn.disabled = true;
    $('errors').textContent = '';
    $('parts').textContent = '';
    $('errTitle').hidden = true;
    $('summary').hidden = true;
    $('bar').hidden = true;
    setStatus('');

    var errors = [], rows = [], ok = 0;
    try {
      var picked = Array.from($('pdfs').files).concat(Array.from($('folder').files))
        .filter(function (f) { return /\.pdf$/i.test(f.name); });
      if (!picked.length) { setStatus('પહેલા PDF ફાઇલો પસંદ કરો.', 'err'); return; }

      var map = null;
      var csvFile = $('csv').files[0];
      if (csvFile) {
        var parsed = N.parseCsv(await csvFile.text());
        map = parsed.map;
        if (parsed.bad) { errors.push('CSV માં ' + parsed.bad + ' લીટી ખોટી હતી (છોડી દીધી)'); }
      }

      // ---- ફાઇલોના નામ ચકાસો ----
      var jobs = [], seen = new Set();
      for (var i = 0; i < picked.length; i++) {
        var f = picked[i];
        var r = N.parseBillName(f.name, { map: map, extraEnabled: C.EXTRA_ENABLED });
        if (r.error) { errors.push(f.name + ': ' + (M[r.error] || M.OTHER)); rows.push(['?', '', 'ERROR']); continue; }
        if (seen.has(r.tenement)) { errors.push(f.name + ': ' + M.DUP); continue; }
        seen.add(r.tenement);
        if (f.size > C.MAX_PDF_MB * 1048576) { errors.push(f.name + ': ' + M.BIG); rows.push([r.tenement, '', 'ERROR']); continue; }
        jobs.push({ file: f, creds: r, id: await N.fileId(C.SITE_ID, r.tenement) });
      }

      // ---- 15000 ની મર્યાદા ----
      var existing = dirHandle ? await listExisting(dirHandle) : new Set();
      var fresh = jobs.filter(function (j) { return !existing.has(j.id); }).length;
      var total = existing.size + fresh;
      if (total > C.MAX_BILLS) {
        setStatus('મર્યાદા ' + C.MAX_BILLS + ' બિલની છે. ફોલ્ડરમાં હાલ ' + existing.size + ', નવા ' + fresh +
          ' = કુલ ' + total + '. ઓછા બિલ પસંદ કરો.', 'err');
        return;
      }
      if (!jobs.length) { setStatus('કોઈ માન્ય PDF મળી નહીં.', 'err'); showErrors(errors); return; }

      var sink = dirHandle ? dirSink(dirHandle) : zipSink(function (n, blob) {
        addDownload('parts', 'ભાગ ' + n + ' (ZIP) ડાઉનલોડ કરો', blob, 'bills-part-' + String(n).padStart(3, '0') + '.zip');
      });

      // ---- એન્ક્રિપ્ટ ----
      var bar = $('bar');
      bar.max = jobs.length; bar.value = 0; bar.hidden = false;
      var idx = 0, doneCount = 0;
      setStatus('એન્ક્રિપ્ટ ચાલુ છે… 0 / ' + jobs.length + ' (બ્રાઉઝર બંધ ન કરો)');

      async function worker() {
        while (idx < jobs.length) {
          var j = jobs[idx++];
          try {
            var bytes = new Uint8Array(await j.file.arrayBuffer());
            var out = await N.encryptBill(bytes, j.creds, C.ITERATIONS);
            await sink.write(j.id + '.bin', out);
            ok++;
            rows.push([j.creds.tenement, j.id, 'OK']);
          } catch (e) {
            errors.push(j.file.name + ': ' + (M[e && e.message] || M.OTHER));
            rows.push([j.creds.tenement, '', 'ERROR']);
          }
          doneCount++;
          bar.value = doneCount;
          if (doneCount % 20 === 0 || doneCount === jobs.length) {
            setStatus('એન્ક્રિપ્ટ ચાલુ છે… ' + doneCount + ' / ' + jobs.length + ' (બ્રાઉઝર બંધ ન કરો)');
          }
        }
      }
      var workers = [];
      for (var k = 0; k < CONCURRENCY; k++) { workers.push(worker()); }
      await Promise.all(workers);
      await sink.finish();

      setStatus(dirHandle
        ? ok + ' બિલ ફોલ્ડરમાં લખાયા ✅ હવે GitHub Desktop થી Commit અને Push કરો.'
        : ok + ' બિલ તૈયાર ✅ નીચેની ZIP ફાઇલો ડાઉનલોડ કરો અને docs/b ફોલ્ડરમાં Extract કરો, પછી Commit અને Push કરો.',
      ok ? 'ok' : 'err');

      var csv = 'tenement,file_id,status\n' + rows.map(function (r) { return r.map(csvCell).join(','); }).join('\n') + '\n';
      var s = $('summary');
      s.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
      s.download = 'upload-summary.csv';
      s.hidden = false;
    } catch (e) {
      setStatus('સમસ્યા આવી: ' + (e && e.message ? e.message : e), 'err');
    } finally {
      showErrors(errors);
      startBtn.disabled = false;
    }
  }

  function showErrors(errors) {
    $('errors').textContent = '';
    if (!errors.length) { $('errTitle').hidden = true; return; }
    $('errTitle').hidden = false;
    errors.slice(0, MAX_ERRORS_SHOWN).forEach(function (t) { addItem('errors', t); });
    if (errors.length > MAX_ERRORS_SHOWN) { addItem('errors', '… અને ' + (errors.length - MAX_ERRORS_SHOWN) + ' વધુ'); }
  }

  $('start').addEventListener('click', run);
})();

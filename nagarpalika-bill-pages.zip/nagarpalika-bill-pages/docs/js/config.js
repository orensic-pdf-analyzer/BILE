/*
 * Site ki settings. Citizen page aur admin page, dono yahi file padhte hain.
 * SITE_ID: pehli baar bills upload karne se PEHLE chahein to badal sakte hain (koi bhi lamba random text).
 *          Bills upload hone ke BAAD ise kabhi na badlein, warna purane sab bills mil nahi payenge.
 */
window.CONFIG = {
  SITE_ID: '8537d7b376ed663b7c34011a',
  ITERATIONS: 600000,        // jitna zyada, utna surakshit (par admin ko encrypt karne me samay lagta hai)
  MAX_BILLS: 15000,          // kul bills ki limit
  MAX_PDF_MB: 20,            // ek PDF ka max size
  BILL_DIR: 'b',             // encrypted bills ka folder (docs/b)
  EXTRA_ENABLED: false,      // true karein to tisra compulsory code (jaise bill ID) bhi poochha jayega
  EXTRA_LABEL: 'વધારાનો કોડ (બિલ પર લખેલ)',
  MAX_FAILS: 5,              // itne galat prayas ke baad
  LOCK_MINUTES: 5            // itni der ke liye rok (sirf us browser me)
};

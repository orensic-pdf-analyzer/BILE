/*
 * Bill encryption helpers. Browser aur Node, dono me chalta hai.
 *
 * File format (docs/b/<id>.bin):
 *   "NPB1" (4) | iterations uint32 BE (4) | salt (16) | iv (12) | AES-256-GCM ciphertext+tag
 * Key = PBKDF2-SHA256( tenement|mobile|extra , salt , iterations )
 * GCM additional data = tenement
 * File id = SHA-256( SITE_ID|tenement ) ke pehle 32 hex akshar
 */
(function (root, factory) {
  'use strict';
  var wc = (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.subtle)
    ? globalThis.crypto
    : (typeof require === 'function' ? require('node:crypto').webcrypto : null);
  var api = factory(wc);
  if (typeof module === 'object' && module.exports) { module.exports = api; } else { root.NPCrypto = api; }
})(typeof self !== 'undefined' ? self : this, function (wc) {
  'use strict';

  var enc = new TextEncoder();
  var MAGIC = [0x4e, 0x50, 0x42, 0x31]; // "NPB1"
  var HEADER_LEN = 4 + 4 + 16 + 12;
  var MIN_ITER = 1000;
  var MAX_ITER = 5000000;

  // ---------- Input saaf karna ----------
  function toAscii(s) {
    return String(s == null ? '' : s).normalize('NFKC').replace(/[૦-૯०-९]/g, function (ch) {
      var c = ch.charCodeAt(0);
      return String(c >= 0x0AE6 && c <= 0x0AEF ? c - 0x0AE6 : c - 0x0966); // Gujarati / Devanagari ank
    });
  }

  function normTenement(s) {
    var t = toAscii(s).toUpperCase().replace(/\s+/g, '').replace(/[\/\\]/g, '-');
    return /^[A-Z0-9-]{1,30}$/.test(t) && /[A-Z0-9]/.test(t) ? t : null;
  }

  function normMobile(s) {
    var d = toAscii(s).replace(/\D/g, '');
    if (d.length === 12 && d.indexOf('91') === 0) { d = d.slice(2); }
    else if (d.length === 11 && d.charAt(0) === '0') { d = d.slice(1); }
    return /^[6-9]\d{9}$/.test(d) ? d : null;
  }

  function normExtra(s) {
    var x = toAscii(s).toUpperCase().replace(/[^A-Z0-9]/g, '');
    return x.length >= 1 && x.length <= 30 ? x : null;
  }

  // ---------- Helpers ----------
  function hex(bytes) {
    var out = '';
    for (var i = 0; i < bytes.length; i++) { out += (bytes[i] + 0x100).toString(16).slice(1); }
    return out;
  }

  function isPdf(bytes) {
    return bytes.length > 4 && bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46; // %PDF
  }

  async function fileId(siteId, tenement) {
    var h = await wc.subtle.digest('SHA-256', enc.encode(siteId + '|' + tenement));
    return hex(new Uint8Array(h)).slice(0, 32);
  }

  async function deriveKey(creds, salt, iterations) {
    var pw = creds.tenement + '|' + creds.mobile + '|' + (creds.extra || '');
    var base = await wc.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveKey']);
    return wc.subtle.deriveKey(
      { name: 'PBKDF2', salt: salt, iterations: iterations, hash: 'SHA-256' },
      base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }

  // ---------- Encrypt / Decrypt ----------
  async function encryptBill(pdfBytes, creds, iterations) {
    if (!isPdf(pdfBytes)) { throw new Error('NOT_PDF_CONTENT'); }
    iterations = iterations || 600000;
    if (iterations < MIN_ITER || iterations > MAX_ITER) { throw new Error('BAD_ITERATIONS'); }
    var salt = wc.getRandomValues(new Uint8Array(16));
    var iv = wc.getRandomValues(new Uint8Array(12));
    var key = await deriveKey(creds, salt, iterations);
    var ct = new Uint8Array(await wc.subtle.encrypt(
      { name: 'AES-GCM', iv: iv, additionalData: enc.encode(creds.tenement) }, key, pdfBytes));
    var out = new Uint8Array(HEADER_LEN + ct.length);
    out.set(MAGIC, 0);
    new DataView(out.buffer).setUint32(4, iterations, false);
    out.set(salt, 8);
    out.set(iv, 24);
    out.set(ct, HEADER_LEN);
    return out;
  }

  async function decryptBill(bytes, creds) {
    if (bytes.length < HEADER_LEN + 16) { throw new Error('BAD_FILE'); }
    for (var i = 0; i < 4; i++) { if (bytes[i] !== MAGIC[i]) { throw new Error('BAD_FILE'); } }
    var iterations = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getUint32(4, false);
    if (iterations < MIN_ITER || iterations > MAX_ITER) { throw new Error('BAD_FILE'); }
    var salt = bytes.slice(8, 24);
    var iv = bytes.slice(24, 36);
    var key = await deriveKey(creds, salt, iterations);
    var plain;
    try {
      plain = new Uint8Array(await wc.subtle.decrypt(
        { name: 'AES-GCM', iv: iv, additionalData: enc.encode(creds.tenement) }, key, bytes.slice(HEADER_LEN)));
    } catch (e) {
      throw new Error('BAD_CREDENTIALS'); // galat tenement/mobile/code
    }
    if (!isPdf(plain)) { throw new Error('BAD_CREDENTIALS'); }
    return plain;
  }

  // ---------- Admin: file ke naam se details nikalna ----------
  // 12345_9876543210.pdf  ya  12345_9876543210_CODE.pdf  ya (CSV ke saath) 12345.pdf
  function parseBillName(fileName, opts) {
    opts = opts || {};
    var base = String(fileName).split(/[\\/]/).pop();
    if (!/\.pdf$/i.test(base)) { return { error: 'NOT_PDF' }; }
    var parts = base.replace(/\.pdf$/i, '').split('_');
    if (parts.length > 3) { return { error: 'BAD_NAME' }; }
    var t = normTenement(parts[0]);
    if (!t) { return { error: 'BAD_TENEMENT' }; }
    var m, x = null;
    if (parts.length === 1) {
      var row = opts.map && opts.map[t];
      if (!row) { return { error: 'NO_MOBILE' }; }
      m = row.mobile;
      x = row.extra || null;
    } else {
      m = normMobile(parts[1]);
      if (parts.length === 3) {
        if (!opts.extraEnabled) { return { error: 'UNEXPECTED_EXTRA' }; }
        x = normExtra(parts[2]);
      }
    }
    if (!m) { return { error: 'BAD_MOBILE' }; }
    if (opts.extraEnabled && !x) { return { error: 'NO_EXTRA' }; }
    if (!opts.extraEnabled) { x = null; }
    return { tenement: t, mobile: m, extra: x };
  }

  // CSV: tenement,mobile[,extra]  (header optional; , ; ya tab chalta hai)
  function parseCsv(text) {
    var map = {}, bad = 0, lines = String(text || '').replace(/^﻿/, '').split(/\r?\n/);
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i].trim();
      if (!line) { continue; }
      var c = line.split(/[,;\t]/).map(function (v) { return v.trim().replace(/^"|"$/g, ''); });
      if (i === 0 && /tenement|tenament|tenamet|ટેનામેન્ટ/i.test(c[0])) { continue; } // header
      var t = normTenement(c[0]), m = normMobile(c[1]);
      if (!t || !m) { bad++; continue; }
      map[t] = { mobile: m, extra: c[2] ? normExtra(c[2]) : null };
    }
    return { map: map, bad: bad };
  }

  return {
    normTenement: normTenement, normMobile: normMobile, normExtra: normExtra,
    fileId: fileId, encryptBill: encryptBill, decryptBill: decryptBill,
    parseBillName: parseBillName, parseCsv: parseCsv, isPdf: isPdf, HEADER_LEN: HEADER_LEN
  };
});

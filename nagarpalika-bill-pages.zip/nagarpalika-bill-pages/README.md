# છોટા ઉદેપુર નગરપાલિકા – Bill Website (bilkul free, GitHub Pages)

Nagrik **tenement number + mobile number** daalta hai aur apna **bill PDF** download kar leta hai.
Admin sirf **PDF** upload karta hai. Website Gujarati me hai (Lohit Gujarati font). Koi server, database ya paisa nahi lagta.

## Ye kaise surakshit hai (free me OTP nahi ho sakta)

OTP SMS ka paisa lagta hai aur uske liye server chahiye, jo GitHub Pages par nahi hota. Isliye yahan **encryption** hai:

- Admin ka browser har PDF ko **tenement + mobile number** se lock (AES-256) karta hai. GitHub par sirf locked `.bin` files jaati hain.
- Nagrik ke browser me wahi tenement + mobile dalne par hi file khulti hai. Galat mobile ya tenement par file **khulti hi nahi**.
- Mobile number kahin bheja ya save nahi hota. File ka naam tenement se bana hash hai, to folder me tenement number dikhte nahi.
- Galat details par hamesha ek hi message aata hai.
- Browser me 5 galat prayas ke baad 5 minute ki rok lagti hai.

**Seedhi baat (limits):**

1. Ye OTP jitna mazboot nahi hai. Free Pages ke liye repo **public** hona padta hai, to koi bhi locked files download karke computer par mobile number ke andaaze laga sakta hai (har andaaze me ~0.1 second lagta hai, par thousands computers se tez ho sakta hai). Rok sirf browser me hai, koi use bypass kar sakta hai.
2. **Isse mazboot karna hai to** `docs/js/config.js` me `EXTRA_ENABLED: true` karein. Tab tisra compulsory code (jaise bill par likhi ID ya janm tithi) bhi poochha jayega, aur andaaza lagana bahut zyada mushkil ho jata hai. Ye pehli upload se pehle chalu karein.
3. Public repo me koi bhi dekh sakta hai ki kitni files hain aur kaun si file hai, par kiska bill hai ye nahi.
4. GitHub Pages ki site ka size lagbhag **1 GB** tak hi allowed hai. 15000 bills ke liye average PDF ~60 KB se chhota hona chahiye. Bade PDF ko pehle compress karein (jaise Ghostscript ya online PDF compressor), nahi to 2 repo me baantein.

## Ek baar ka setup (laga-bhag 10 minute)

1. github.com par naya **public** repo banayein (jaise `bill-portal`) aur is folder ki saari files upload karein (GitHub Desktop sabse aasan hai).
2. Repo → **Settings → Pages** → Source: *Deploy from a branch* → Branch: `main`, Folder: **/docs** → Save.
3. 1-2 minute baad website `https://<aapka-naam>.github.io/<repo-naam>/` par chalu ho jayegi. Admin page: `.../admin.html`.
4. **Gujarati font:** Lohit Gujarati ki `.ttf` file (open-source, official: Lohit fonts project, pagure.io/lohit) download karke `docs/fonts/Lohit-Gujarati.ttf` naam se rakhein. Isse har phone/computer par wahi font dikhega. File na rakhein to Noto Sans Gujarati / Nirmala UI jaise font se Gujarati phir bhi sahi dikhegi.
5. (Zaroori nahi) `docs/js/config.js` me `SITE_ID` badal sakte hain. **Pehli upload ke baad kabhi nahi badalna**, warna purane bills khul nahi payenge.

## Admin: bills kaise upload karein

1. PDF ka naam rakhein: **`tenement_mobile.pdf`**, jaise `12345_9876543210.pdf`.
   (Agar `EXTRA_ENABLED` chalu hai to `12345_9876543210_AB12.pdf`.)
   Naam me mobile na ho to PDF ka naam sirf `12345.pdf` rakhein aur admin page par ek CSV (`tenement,mobile`) bhi chunein.
2. Chrome ya Edge me `admin.html` kholein (apne computer par repo ka `docs/admin.html` bhi khol sakte hain).
3. **PDF ya poora folder chunein** → **"ફોલ્ડર પસંદ કરો"** me apne repo ka `docs/b` folder chunein → **"એન્ક્રિપ્ટ કરો"**.
   (Doosre browser me ZIP bante hain. Unhe `docs/b` me Extract karein.)
4. **GitHub Desktop** kholein → **Commit** → **Push**. 1-2 minute me bill live.

- 15000 bills me lagbhag 12-15 minute lagte hain. Tab tak browser band na karein. Aap kam kam bills ke batch me bhi daal sakte hain.
- **Limit 15000** hai. Folder mode me page `docs/b` ke maujooda bills ginta hai aur limit paar hone par rok deta hai. Kisi bill ko dobara daalne par wo badal jata hai aur ginti me nahi badhta.
- Bill hatana ho to `docs/b` se uski `.bin` file delete karke Push karein. Admin page ka "યાદી (CSV)" sirf aapke records ke liye hai, ise GitHub par na daalein.
- **Mool PDF aur CSV kabhi repo me na daalein.** `.gitignore` inhe rokta hai, phir bhi dhyan rakhein.
- Admin page par password nahi hai. Wahan se kuch upload nahi hota. Asli suraksha ye hai ki repo me sirf aapko likhne ki permission hai.

## Test chalana

```
node tests/crypto.test.mjs
```
(Node 18+ chahiye, koi package nahi.) Isme encryption, galat details, ZIP aur naam/CSV parsing ke 44 test hain.

## Files

| Path | Kaam |
|---|---|
| `docs/index.html` | Nagrik ka page |
| `docs/admin.html` | Admin ka PDF upload page |
| `docs/js/config.js` | Settings (limit, SITE_ID, extra code) |
| `docs/js/npcrypto.js` | Encryption (AES-256-GCM, PBKDF2 600000 iterations) |
| `docs/js/zip.js` | ZIP banana (jab folder seedha na chuna ja sake) |
| `docs/b/` | Encrypted bills (`.bin`) yahin jaate hain |
| `docs/fonts/` | Lohit Gujarati font yahan rakhein |

// Chalane ke liye:  node tests/crypto.test.mjs   (Node 18+, koi package nahi chahiye)
import { createRequire } from 'node:module';
import { writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';

const require = createRequire(import.meta.url);
const N = require('../docs/js/npcrypto.js');
const Z = require('../docs/js/zip.js');

let failed = 0;
const ok = (name, cond) => { console.log((cond ? 'PASS ' : 'FAIL ') + name); if (!cond) failed++; };
const rejects = async (p) => { try { await p; return null; } catch (e) { return e.message; } };

const pdf = new TextEncoder().encode('%PDF-1.4\n' + 'bill data '.repeat(5000));
const creds = { tenement: '12345', mobile: '9876543210', extra: null };
const ITER = 2000; // test me tez rakha; asli site 600000 use karti hai

// ---- normalisation ----
ok('tenement: spaces/lowercase/slash', N.normTenement(' ab/12 3 ') === 'AB-123');
ok('tenement: Gujarati digits', N.normTenement('૧૨૩૪૫') === '12345');
ok('tenement: underscore rejected', N.normTenement('12_3') === null);
ok('tenement: empty rejected', N.normTenement('   ') === null);
ok('mobile: plain', N.normMobile('9876543210') === '9876543210');
ok('mobile: +91 with spaces', N.normMobile('+91 98765-43210') === '9876543210');
ok('mobile: leading 0', N.normMobile('09876543210') === '9876543210');
ok('mobile: Gujarati digits', N.normMobile('૯૮૭૬૫૪૩૨૧૦') === '9876543210');
ok('mobile: starts with 5 rejected', N.normMobile('5876543210') === null);
ok('mobile: 9 digits rejected', N.normMobile('987654321') === null);

// ---- encrypt / decrypt ----
const enc = await N.encryptBill(pdf, creds, ITER);
ok('encrypted starts with NPB1', String.fromCharCode(...enc.slice(0, 4)) === 'NPB1');
ok('plain text not visible in encrypted file', !Buffer.from(enc).includes(Buffer.from('bill data')));
ok('decrypt roundtrip', Buffer.compare(Buffer.from(await N.decryptBill(enc, creds)), Buffer.from(pdf)) === 0);
ok('wrong mobile fails', (await rejects(N.decryptBill(enc, { ...creds, mobile: '9876543211' }))) === 'BAD_CREDENTIALS');
ok('wrong tenement fails', (await rejects(N.decryptBill(enc, { ...creds, tenement: '12346' }))) === 'BAD_CREDENTIALS');
ok('missing extra fails', (await rejects(N.decryptBill(enc, { ...creds, extra: 'ABC' }))) === 'BAD_CREDENTIALS');
const enc2 = await N.encryptBill(pdf, { ...creds, extra: 'ABC123' }, ITER);
ok('extra code roundtrip', (await N.decryptBill(enc2, { ...creds, extra: 'ABC123' })).length === pdf.length);
ok('extra code wrong fails', (await rejects(N.decryptBill(enc2, { ...creds, extra: 'ABC124' }))) === 'BAD_CREDENTIALS');
const tampered = enc.slice(); tampered[tampered.length - 5] ^= 1;
ok('tampered file fails', (await rejects(N.decryptBill(tampered, creds))) === 'BAD_CREDENTIALS');
ok('truncated file fails', (await rejects(N.decryptBill(enc.slice(0, 20), creds))) === 'BAD_FILE');
ok('junk file fails', (await rejects(N.decryptBill(new Uint8Array(200), creds))) === 'BAD_FILE');
ok('same input gives different ciphertext (random salt/iv)', Buffer.compare(Buffer.from(enc), Buffer.from(await N.encryptBill(pdf, creds, ITER))) !== 0);
ok('non-PDF refused', (await rejects(N.encryptBill(new TextEncoder().encode('hello world'), creds, ITER))) === 'NOT_PDF_CONTENT');
const badIter = enc.slice(); new DataView(badIter.buffer).setUint32(4, 2_000_000_000, false);
ok('absurd iteration count in header refused', (await rejects(N.decryptBill(badIter, creds))) === 'BAD_FILE');

// ---- file ids ----
const id1 = await N.fileId('SITE', '12345');
ok('fileId is 32 hex', /^[0-9a-f]{32}$/.test(id1));
ok('fileId depends on site id', id1 !== await N.fileId('OTHER', '12345'));
ok('fileId depends on tenement', id1 !== await N.fileId('SITE', '12346'));

// ---- file names + CSV ----
const P = (n, o) => N.parseBillName(n, o);
ok('name T_M.pdf', JSON.stringify(P('12345_9876543210.pdf')) === JSON.stringify({ tenement: '12345', mobile: '9876543210', extra: null }));
ok('name with +91 is not split wrongly', P('12345_+919876543210.pdf').mobile === '9876543210');
ok('name uppercase .PDF accepted', !P('12345_9876543210.PDF').error);
ok('name with folder path', P('folder/sub/12345_9876543210.pdf').tenement === '12345');
ok('name without mobile -> NO_MOBILE', P('12345.pdf').error === 'NO_MOBILE');
ok('name bad mobile', P('12345_12345.pdf').error === 'BAD_MOBILE');
ok('name not pdf', P('12345.txt').error === 'NOT_PDF');
ok('name 4 parts', P('1_9876543210_A_B.pdf').error === 'BAD_NAME');
ok('extra part when disabled -> error', P('1_9876543210_AB.pdf').error === 'UNEXPECTED_EXTRA');
ok('extra enabled: T_M_X', P('1_9876543210_ab-12.pdf', { extraEnabled: true }).extra === 'AB12');
ok('extra enabled: missing extra -> error', P('1_9876543210.pdf', { extraEnabled: true }).error === 'NO_EXTRA');
const csv = N.parseCsv('﻿tenement,mobile,extra\r\n101,98765 43210,x1\r\n102;+91 9123456789\r\n103,123\r\n\r\n"104","9000000001"\r\n');
ok('csv: 3 valid, 1 bad', Object.keys(csv.map).length === 3 && csv.bad === 1);
ok('csv: parsed mobile/extra', csv.map['101'].mobile === '9876543210' && csv.map['101'].extra === 'X1');
ok('name T.pdf + csv', P('101.pdf', { map: csv.map }).mobile === '9876543210');
ok('csv without header', Object.keys(N.parseCsv('5,9876543210\n6,9123456789').map).length === 2);

// ---- zip (Python ke zipfile se verify) ----
const files = [
  { name: 'aaaa.bin', data: enc },
  { name: 'bbbb.bin', data: enc2 },
  { name: 'empty.bin', data: new Uint8Array(0) },
];
const parts = Z.makeZip(files);
const zipPath = join(mkdtempSync(join(tmpdir(), 'zip-')), 't.zip');
writeFileSync(zipPath, Buffer.concat(parts.map((p) => Buffer.from(p))));
const py = `
import zipfile, sys, hashlib
z = zipfile.ZipFile(sys.argv[1])
assert z.testzip() is None
print(','.join(z.namelist()))
print(hashlib.sha256(z.read('aaaa.bin')).hexdigest())
`;
const out = execFileSync('python3', ['-c', py, zipPath]).toString().trim().split('\n');
const sha = (await import('node:crypto')).createHash('sha256').update(enc).digest('hex');
ok('zip opens in Python, names right', out[0] === 'aaaa.bin,bbbb.bin,empty.bin');
ok('zip content matches (CRC ok)', out[1] === sha);

console.log(failed ? `\n${failed} test FAIL` : '\nSab test paas');
process.exit(failed ? 1 : 0);
